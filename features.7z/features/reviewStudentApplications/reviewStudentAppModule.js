(function() {
    'use strict';

    angular.module('reviewStudentApp', []);

})();
