(function() {
    'use strict';
    angular.module('main-page', []);
})();
