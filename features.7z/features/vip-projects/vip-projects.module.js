(function() {
    'use strict';

    angular.module('vip-projects', []);	

})();
