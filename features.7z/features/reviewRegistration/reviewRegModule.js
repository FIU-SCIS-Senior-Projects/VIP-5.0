(function() {
    'use strict';

    angular.module('reviewRegistration', ['userService']);

})();
