(function() {
    'use strict';

    angular.module('messenger', []);

})();
