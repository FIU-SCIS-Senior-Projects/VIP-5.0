(function() {
    'use strict';

    angular.module('reviewProjectProposals', []);

})();
